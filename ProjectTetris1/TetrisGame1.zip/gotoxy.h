#pragma once
using namespace std;
#include <iostream>

#include <windows.h>
#include <process.h>
#include <stdlib.h>
#include <conio.h>
#include <fstream>
#include <stdio.h>
#include"enum.h"




void gotoxy(int x, int y);
void clrscr();
void hideCursor();
 
void setTextColor(Color colorToSet);
