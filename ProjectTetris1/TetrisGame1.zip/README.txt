Student 1: Gal katz, id : 313417933

Student 2: Shay Ashkenazi, id: 208432799


